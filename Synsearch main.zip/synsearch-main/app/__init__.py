"""
Dashboard application for research paper analysis using arXiv API.
"""

from .app import app

__all__ = ['app'] 