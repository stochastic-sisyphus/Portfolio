interface EnvConfig {
  OPENAI_API_KEY: string | undefined;
  isDevelopment: boolean;
  isProduction: boolean;
}

export const env: EnvConfig = {
  OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY,
  isDevelopment: import.meta.env.DEV,
  isProduction: import.meta.env.PROD,
};

export function validateEnv(): string[] {
  const missingVars: string[] = [];

  if (!env.OPENAI_API_KEY) {
    missingVars.push('VITE_OPENAI_API_KEY');
  }

  return missingVars;
}